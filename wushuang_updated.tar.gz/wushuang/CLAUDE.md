# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Polymarket BTC 5-minute prediction market trading bot. Monitors BTC price movements on Polymarket's CLOB (Central Limit Order Book) and executes algorithmic trades on 5-minute UP/DOWN prediction markets.

## Running

```bash
# Install dependencies (no requirements.txt exists)
pip install flask websockets requests eth-account

# Run the API server (required by btc_5m_grid.py)
python trade_server.py  # Listens on 0.0.0.0:5001

# Run trading bot (choose one)
python btc_5m_grid.py       # Standalone bot, uses trade_server at :5001
python btc_5m_unified.py    # Integrated version, direct Polymarket API, uses config.json
```

No tests, no linter, no build step.

## Architecture

Three independent Python scripts with overlapping functionality:

- **btc_5m_grid.py** — Async trading bot using `asyncio`+`websockets`. Connects to Polymarket WebSocket for real-time prices. Sends orders via local `trade_server.py` at `:5001`. All trading parameters are hardcoded constants.

- **btc_5m_unified.py** — Self-contained trading bot with `PolymarketTrader` class that signs and sends orders directly to Polymarket CLOB API. Gets prices from a separate local API at `:5007/api/orderbook`. Reads parameters from `config.json` (auto-generated on first run). Uses `threading` for WebSocket + trading loop.

- **trade_server.py** — Flask REST API wrapping an external `TradingClient` from `/home/ubuntu/polymarket_maker`. Provides `/order`, `/cancel/<id>`, `/orders`, `/trades`, `/positions` endpoints. Only used by `btc_5m_grid.py`.

## Trading Strategy

Both bots implement the same core strategy:
1. **Entry**: Buy UP or DOWN when price reaches threshold (default 55%), skip if above no-entry threshold (85%)
2. **Hedge**: When price rises 5% above entry, buy opposite direction to lock in profit
3. **Stop-loss**: When price drops below 50%, buy opposite direction for all hedged positions
4. **Take-profit**: Sell at 99% (grid version only)
5. **Position limits**: Max 2 concurrent hedge positions per direction (grid version only)
6. **Time restriction**: No trading during configurable hours (default 21:00-22:00 Beijing time)

## Key Details

- Token IDs are scraped from Polymarket event pages using regex for 50+ digit numbers
- The grid version uses Beijing timezone (UTC+8) with 30-minute offsets for trade windows
- The unified version authenticates via Ethereum private key signing (ECDSA)
- All prices are probabilities between 0.0 and 1.0 (displayed as percentages)
- 5-minute windows are calculated as `(unix_timestamp // 300) * 300`
