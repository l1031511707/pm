# BTC Trader 合并+GUI 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将三个Python文件合并为单文件 btc_trader.py，带 tkinter GUI，可打包为 Windows exe。

**Architecture:** 单文件四个类：PolymarketTrader（API下单）、PriceWatcher（WebSocket价格）、TradingEngine（策略逻辑）、TradingApp（GUI）。交易线程+asyncio事件循环运行在daemon线程中，GUI通过 root.after() 定时刷新。

**Tech Stack:** Python 3, tkinter, websockets, asyncio, eth_account, requests, PyInstaller

---

## 已发现的代码逻辑问题（合并时修正）

1. **禁止交易时间窗口bug**（btc_5m_grid.py:109）：`NO_TRADE_START <= hour` 应为 `NO_TRADE_START < hour`，否则整个起始小时都被阻止（实际阻止21:00-22:30而非预期的21:30-22:30）
2. **sign_message缺少encode_defunct**（btc_5m_unified.py:93）：`account.sign_message(message)` 需要 `SignableMessage` 对象，应使用 `encode_defunct(text=message)`
3. **unified版交易逻辑不完整**：缺少止盈、对冲队列、对冲队列限制 — 以grid版为准
4. **unified版可同时买UP和DOWN**（btc_5m_unified.py:224-234）：用 `if` 而非 `elif`，同一周期可能双向建仓 — 以grid版的 `elif` 逻辑为准

---

### Task 1: 创建 btc_trader.py — 配置管理 + PolymarketTrader

**Files:**
- Create: `btc_trader.py`

- [ ] **Step 1: 写入文件头、imports和配置管理**

```python
#!/usr/bin/env python3
"""BTC 5分钟交易策略 - 合并版 (GUI)"""
import asyncio, json, time, requests, websockets, ssl, re, os, sys, threading
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from datetime import datetime, timezone, timedelta
from eth_account import Account
from eth_account.messages import encode_defunct

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

DEFAULT_CONFIG = {
    "api": {"key": "", "address": ""},
    "trading": {
        "threshold": 0.55, "stop_loss": 0.50, "hedge_profit": 0.05,
        "no_entry": 0.85, "size": 15, "no_trade_start": 21, "no_trade_end": 22
    }
}

def load_config():
    path = os.path.join(get_script_dir(), 'config.json')
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return DEFAULT_CONFIG.copy()

def save_config(config):
    path = os.path.join(get_script_dir(), 'config.json')
    with open(path, 'w') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
```

- [ ] **Step 2: 写入 PolymarketTrader 类**

```python
class PolymarketTrader:
    def __init__(self, api_key, signer_address, private_key):
        self.api_key = api_key
        self.signer_address = signer_address
        self.private_key = private_key
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

    def sign_message(self, message):
        account = Account.from_key(self.private_key)
        msg = encode_defunct(text=message)
        signed = account.sign_message(msg)
        return signed.signature.hex()

    def get_clob_headers(self):
        timestamp = str(int(time.time()))
        message = f"Polymarket CLOB Auth\n\nAddress: {self.signer_address}\nTimestamp: {timestamp}\nNonce: 0"
        signature = self.sign_message(message)
        return {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
            'X-Polymarket-Signature': signature,
            'X-Polymarket-Timestamp': timestamp,
            'X-Polymarket-Address': self.signer_address
        }

    def place_order(self, token_id, side, price, size):
        url = "https://clob.polymarket.com/orders"
        data = {"token_id": token_id, "side": side, "price": round(price, 2), "size": size}
        try:
            resp = self.session.post(url, json=data, headers=self.get_clob_headers(), timeout=30)
            if resp.status_code in [200, 201]:
                return {"success": True, "data": resp.json()}
            return {"success": False, "error": f"{resp.status_code} {resp.text}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_positions(self):
        url = f"https://clob.polymarket.com/positions?address={self.signer_address}"
        try:
            resp = self.session.get(url, headers=self.get_clob_headers(), timeout=10)
            if resp.status_code == 200:
                positions = resp.json()
                up = down = 0
                for p in positions:
                    if p.get('side') == 'Buy':
                        if p.get('outcome') == 'Yes' or 'yes' in p.get('asset', '').lower():
                            up += float(p.get('size', 0))
                        else:
                            down += float(p.get('size', 0))
                return up, down
        except:
            pass
        return 0, 0
```

- [ ] **Step 3: 验证语法**

Run: `python -c "import ast; ast.parse(open('btc_trader.py').read()); print('OK')"`
Expected: OK

- [ ] **Step 4: Commit**

```bash
git add btc_trader.py
git commit -m "feat: btc_trader.py — config management + PolymarketTrader"
```

---

### Task 2: PriceWatcher + get_token

**Files:**
- Modify: `btc_trader.py` (append)

- [ ] **Step 1: 追加 PriceWatcher 类**

```python
class PriceWatcher:
    def __init__(self, on_price_update=None):
        self.ws = None
        self.yes_tok = None
        self.no_tok = None
        self.last_prices = (0.5, 0.5)
        self.running = False
        self.lock = asyncio.Lock()
        self.on_price_update = on_price_update

    async def start(self, yes_tok, no_tok):
        self.yes_tok = yes_tok
        self.no_tok = no_tok
        self.running = True
        asyncio.create_task(self._listen())

    async def _listen(self):
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE
        while self.running:
            try:
                if not self.ws:
                    self.ws = await websockets.connect(
                        'wss://ws-subscriptions-clob.polymarket.com/ws/market',
                        ssl=ssl_ctx
                    )
                    await self.ws.send(json.dumps({
                        "assets_ids": [self.yes_tok, self.no_tok],
                        "type": "market"
                    }))
                async for msg in self.ws:
                    if not self.running:
                        break
                    try:
                        data = json.loads(msg)
                        if "price" in data:
                            price = float(data["price"])
                            tok = data.get("asset_id", "")
                            async with self.lock:
                                if tok == self.yes_tok:
                                    self.last_prices = (price, self.last_prices[1])
                                elif tok == self.no_tok:
                                    self.last_prices = (self.last_prices[0], price)
                            if self.on_price_update:
                                self.on_price_update(self.last_prices)
                    except (json.JSONDecodeError, ValueError):
                        pass
            except Exception:
                self.ws = None
                if self.running:
                    await asyncio.sleep(1)

    async def get_price(self):
        async with self.lock:
            return self.last_prices

    async def stop(self):
        self.running = False
        if self.ws:
            try:
                await self.ws.close()
            except Exception:
                pass
            self.ws = None
```

- [ ] **Step 2: 追加 get_token 函数**

```python
def get_token(window):
    try:
        url = f"https://polymarket.com/event/btc-updown-5m-{window}"
        r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if r.status_code != 200:
            return None, None
        ids = list(set(re.findall(r'\b(\d{50,})\b', r.text)))
        if len(ids) >= 2:
            return ids[0], ids[1]
    except Exception:
        pass
    return None, None
```

- [ ] **Step 3: 验证语法**

Run: `python -c "import ast; ast.parse(open('btc_trader.py').read()); print('OK')"`
Expected: OK

- [ ] **Step 4: Commit**

```bash
git add btc_trader.py
git commit -m "feat: PriceWatcher + get_token"
```

---

### Task 3: TradingEngine（核心策略逻辑）

**Files:**
- Modify: `btc_trader.py` (append)

- [ ] **Step 1: 追加 TradingEngine 类**

```python
class TradingEngine:
    def __init__(self, trader, log_callback=None):
        self.trader = trader  # PolymarketTrader instance
        self.watcher = PriceWatcher()
        self.log = log_callback or print
        # 状态
        self.up_shares = 0
        self.down_shares = 0
        self.up_hedges = []
        self.down_hedges = []
        self.last_window = 0
        self.yes_tok = None
        self.no_tok = None
        self.running = False
        self.loop = None
        # 参数（从config加载，GUI可修改）
        self.threshold = 0.55
        self.stop_loss = 0.50
        self.hedge_profit = 0.05
        self.no_entry = 0.85
        self.size = 15
        self.no_trade_start = 21
        self.no_trade_end = 22
        # 实时状态（GUI读取）
        self.up_price = 0.5
        self.down_price = 0.5
        self.remaining = 0

    def update_params(self, config):
        t = config.get('trading', {})
        self.threshold = t.get('threshold', 0.55)
        self.stop_loss = t.get('stop_loss', 0.50)
        self.hedge_profit = t.get('hedge_profit', 0.05)
        self.no_entry = t.get('no_entry', 0.85)
        self.size = t.get('size', 15)
        self.no_trade_start = t.get('no_trade_start', 21)
        self.no_trade_end = t.get('no_trade_end', 22)

    def is_trading_allowed(self):
        beijing_tz = timezone(timedelta(hours=8))
        now = datetime.now(beijing_tz)
        hour, minute = now.hour, now.minute
        if hour == self.no_trade_start and minute >= 30:
            return False
        if hour == self.no_trade_end and minute < 30:
            return False
        # 修正：用 < 而非 <= 避免阻止整个起始小时
        if self.no_trade_start < hour < self.no_trade_end:
            return False
        return True

    def _send_order(self, token, side, price, size):
        result = self.trader.place_order(token, side, price, size)
        if result.get("success"):
            self.log(f"  ✅ {side} {size}张 @ {price:.2f} 成功")
        else:
            self.log(f"  ❌ {side} 失败: {result.get('error', '未知错误')}")
        return result

    async def _run(self):
        self.log("交易引擎启动")
        while self.running:
            current_ts = int(time.time())
            window = (current_ts // 300) * 300

            # 窗口切换
            if window != self.last_window:
                self.log(f"\n=== 新窗口 {datetime.now().strftime('%H:%M')} ===")
                self.last_window = window
                self.up_hedges = []
                self.down_hedges = []
                self.up_shares = 0
                self.down_shares = 0
                await self.watcher.stop()
                self.yes_tok, self.no_tok = get_token(window)
                if self.yes_tok:
                    await self.watcher.start(self.yes_tok, self.no_tok)
                    self.log(f"Token已获取，WebSocket已连接")
                else:
                    self.log(f"⚠ 无法获取Token，等待重试...")
                await asyncio.sleep(2)
                continue

            if not self.yes_tok:
                self.yes_tok, self.no_tok = get_token(window)
                if not self.yes_tok:
                    await asyncio.sleep(5)
                    continue

            up_price, down_price = await self.watcher.get_price()
            self.up_price = up_price
            self.down_price = down_price
            self.remaining = window + 300 - current_ts

            t = datetime.now().strftime("%H:%M:%S")
            self.log(f"[{t}] UP={up_price*100:.0f}% DOWN={down_price*100:.0f}% "
                     f"剩{self.remaining}s | 持仓:UP={self.up_shares} DOWN={self.down_shares}")

            # 99%止盈
            if up_price >= 0.99 and self.up_shares > 0:
                self.log(f"  🎯 UP达到99% → 卖出UP {self.up_shares}张")
                result = self._send_order(self.yes_tok, "sell", 0.01, self.up_shares)
                if result.get("success"):
                    self.up_shares = 0
                    self.up_hedges = []
            elif down_price >= 0.99 and self.down_shares > 0:
                self.log(f"  🎯 DOWN达到99% → 卖出DOWN {self.down_shares}张")
                result = self._send_order(self.no_tok, "sell", 0.01, self.down_shares)
                if result.get("success"):
                    self.down_shares = 0
                    self.down_hedges = []

            # 止损
            if up_price < self.stop_loss and self.up_hedges:
                total = sum(h["shares"] for h in self.up_hedges)
                self.log(f"  🛑 UP止损! {up_price*100:.0f}%<{self.stop_loss*100:.0f}% → 买DOWN x{total}")
                result = self._send_order(self.no_tok, "buy", down_price, total)
                if result.get("success"):
                    self.down_shares += total
                    self.up_hedges = []

            if down_price < self.stop_loss and self.down_hedges:
                total = sum(h["shares"] for h in self.down_hedges)
                self.log(f"  🛑 DOWN止损! {down_price*100:.0f}%<{self.stop_loss*100:.0f}% → 买UP x{total}")
                result = self._send_order(self.yes_tok, "buy", up_price, total)
                if result.get("success"):
                    self.up_shares += total
                    self.down_hedges = []

            # 对冲
            for hedge in self.up_hedges[:]:
                if up_price >= hedge["price"] + self.hedge_profit:
                    hedge_price = 1.0 - (hedge["price"] + self.hedge_profit)
                    self.log(f"  🎯 UP对冲 → 买DOWN x{hedge['shares']} @ {hedge_price:.2f}")
                    result = self._send_order(self.no_tok, "buy", hedge_price, hedge["shares"])
                    if result.get("success"):
                        self.down_shares += hedge["shares"]
                        self.up_hedges.remove(hedge)

            for hedge in self.down_hedges[:]:
                if down_price >= hedge["price"] + self.hedge_profit:
                    hedge_price = 1.0 - (hedge["price"] + self.hedge_profit)
                    self.log(f"  🎯 DOWN对冲 → 买UP x{hedge['shares']} @ {hedge_price:.2f}")
                    result = self._send_order(self.yes_tok, "buy", hedge_price, hedge["shares"])
                    if result.get("success"):
                        self.up_shares += hedge["shares"]
                        self.down_hedges.remove(hedge)

            # 建仓
            if self.is_trading_allowed():
                if len(self.up_hedges) >= 2 or len(self.down_hedges) >= 2:
                    pass  # 对冲队列已满，暂停建仓
                elif up_price >= self.threshold and up_price < self.no_entry:
                    self.log(f"  🟢 UP>{self.threshold*100:.0f}% → 买UP @ {up_price:.2f} x{self.size}")
                    result = self._send_order(self.yes_tok, "buy", up_price, self.size)
                    if result.get("success"):
                        self.up_shares += self.size
                        self.up_hedges.append({"price": up_price, "shares": self.size})
                elif down_price >= self.threshold and down_price < self.no_entry:
                    self.log(f"  🟢 DOWN>{self.threshold*100:.0f}% → 买DOWN @ {down_price:.2f} x{self.size}")
                    result = self._send_order(self.no_tok, "buy", down_price, self.size)
                    if result.get("success"):
                        self.down_shares += self.size
                        self.down_hedges.append({"price": down_price, "shares": self.size})
            else:
                self.log(f"  ⏸ {self.no_trade_start}:30-{self.no_trade_end}:30 禁止交易时段")

            await asyncio.sleep(5)

        await self.watcher.stop()
        self.log("交易引擎已停止")

    def start(self):
        self.running = True
        def run():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.loop.run_until_complete(self._run())
        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
```

- [ ] **Step 2: 验证语法**

Run: `python -c "import ast; ast.parse(open('btc_trader.py').read()); print('OK')"`
Expected: OK

- [ ] **Step 3: Commit**

```bash
git add btc_trader.py
git commit -m "feat: TradingEngine with full strategy logic"
```

---

### Task 4: TradingApp GUI

**Files:**
- Modify: `btc_trader.py` (append)

- [ ] **Step 1: 追加 TradingApp 类 — 窗口框架和配置面板**

```python
class TradingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BTC 5分钟交易策略")
        self.geometry("780x600")
        self.resizable(True, True)
        self.config_data = load_config()
        self.engine = None
        self.trader = None
        self.entries = {}
        self._build_ui()
        self._load_config_to_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill=tk.X, padx=5, pady=5)

        # === 左侧：参数配置 ===
        left = ttk.LabelFrame(top, text="参数配置")
        left.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 5))

        api_fields = [("API Key", "api_key"), ("钱包地址", "address"), ("私钥", "private_key")]
        for i, (label, key) in enumerate(api_fields):
            ttk.Label(left, text=label + ":").grid(row=i, column=0, sticky=tk.W, padx=2, pady=1)
            e = ttk.Entry(left, width=28, show="*" if key == "private_key" else "")
            e.grid(row=i, column=1, padx=2, pady=1)
            self.entries[key] = e

        trading_fields = [
            ("买入阈值", "threshold"), ("止损线", "stop_loss"),
            ("对冲利润", "hedge_profit"), ("禁入阈值", "no_entry"),
            ("每次数量", "size"), ("禁交易开始(时)", "no_trade_start"),
            ("禁交易结束(时)", "no_trade_end"),
        ]
        offset = len(api_fields)
        for i, (label, key) in enumerate(trading_fields):
            ttk.Label(left, text=label + ":").grid(row=offset + i, column=0, sticky=tk.W, padx=2, pady=1)
            e = ttk.Entry(left, width=10)
            e.grid(row=offset + i, column=1, sticky=tk.W, padx=2, pady=1)
            self.entries[key] = e

        btn_frame = ttk.Frame(left)
        btn_frame.grid(row=offset + len(trading_fields), column=0, columnspan=2, pady=5)
        self.start_btn = ttk.Button(btn_frame, text="▶ 启动", command=self._start_trading)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        self.stop_btn = ttk.Button(btn_frame, text="■ 停止", command=self._stop_trading, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)

        # === 右侧：实时状态 ===
        right = ttk.LabelFrame(top, text="实时状态")
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.status_labels = {}
        status_items = [
            ("UP价格", "up_price"), ("DOWN价格", "down_price"),
            ("剩余时间", "remaining"), ("UP持仓", "up_shares"),
            ("DOWN持仓", "down_shares"), ("UP对冲队列", "up_hedges"),
            ("DOWN对冲队列", "down_hedges"),
        ]
        for i, (label, key) in enumerate(status_items):
            ttk.Label(right, text=label + ":").grid(row=i, column=0, sticky=tk.W, padx=5, pady=2)
            lbl = ttk.Label(right, text="--")
            lbl.grid(row=i, column=1, sticky=tk.W, padx=5, pady=2)
            self.status_labels[key] = lbl

        # === 底部：日志 ===
        log_frame = ttk.LabelFrame(self, text="日志")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=12, state=tk.DISABLED, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)

    def _load_config_to_ui(self):
        api = self.config_data.get('api', {})
        self.entries['api_key'].insert(0, api.get('key', ''))
        self.entries['address'].insert(0, api.get('address', ''))
        t = self.config_data.get('trading', {})
        for key in ['threshold', 'stop_loss', 'hedge_profit', 'no_entry', 'size', 'no_trade_start', 'no_trade_end']:
            self.entries[key].insert(0, str(t.get(key, '')))

    def _save_config_from_ui(self):
        self.config_data['api'] = {
            'key': self.entries['api_key'].get(),
            'address': self.entries['address'].get()
        }
        t = self.config_data.setdefault('trading', {})
        for key in ['threshold', 'stop_loss', 'hedge_profit', 'no_entry']:
            try: t[key] = float(self.entries[key].get())
            except ValueError: pass
        for key in ['size', 'no_trade_start', 'no_trade_end']:
            try: t[key] = int(self.entries[key].get())
            except ValueError: pass
        save_config(self.config_data)

    def _log(self, msg):
        def _append():
            self.log_text.config(state=tk.NORMAL)
            self.log_text.insert(tk.END, msg + "\n")
            self.log_text.see(tk.END)
            self.log_text.config(state=tk.DISABLED)
        self.after(0, _append)

    def _start_trading(self):
        self._save_config_from_ui()
        pk = self.entries['private_key'].get().strip()
        if pk.startswith('0x'):
            pk = pk[2:]
        if not pk or len(pk) != 64:
            messagebox.showerror("错误", "私钥格式错误（需要64位hex）")
            return
        try:
            account = Account.from_key(pk)
            self._log(f"✅ 私钥有效，地址: {account.address}")
        except Exception:
            messagebox.showerror("错误", "私钥无效")
            return

        api_key = self.entries['api_key'].get().strip()
        address = self.entries['address'].get().strip()
        self.trader = PolymarketTrader(api_key, address, pk)
        self.engine = TradingEngine(self.trader, log_callback=self._log)
        self.engine.update_params(self.config_data)
        self.engine.start()

        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        for e in self.entries.values():
            e.config(state=tk.DISABLED)
        self._update_status()

    def _stop_trading(self):
        if self.engine:
            self.engine.stop()
            self._log("交易已停止")
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        for e in self.entries.values():
            e.config(state=tk.NORMAL)

    def _update_status(self):
        if self.engine and self.engine.running:
            self.status_labels['up_price'].config(text=f"{self.engine.up_price*100:.1f}%")
            self.status_labels['down_price'].config(text=f"{self.engine.down_price*100:.1f}%")
            self.status_labels['remaining'].config(text=f"{self.engine.remaining}s")
            self.status_labels['up_shares'].config(text=str(self.engine.up_shares))
            self.status_labels['down_shares'].config(text=str(self.engine.down_shares))
            self.status_labels['up_hedges'].config(text=f"{len(self.engine.up_hedges)}/2")
            self.status_labels['down_hedges'].config(text=f"{len(self.engine.down_hedges)}/2")
            self.after(1000, self._update_status)

    def _on_close(self):
        if self.engine and self.engine.running:
            self.engine.stop()
        self.destroy()
```

- [ ] **Step 2: 追加 main 入口**

```python
if __name__ == "__main__":
    app = TradingApp()
    app.mainloop()
```

- [ ] **Step 3: 验证语法**

Run: `python -c "import ast; ast.parse(open('btc_trader.py').read()); print('OK')"`
Expected: OK

- [ ] **Step 4: Commit**

```bash
git add btc_trader.py
git commit -m "feat: TradingApp GUI + main entry point"
```

---

### Task 5: build.bat

**Files:**
- Create: `build.bat`

- [ ] **Step 1: 创建 build.bat**

```bat
@echo off
echo === BTC Trader Build ===
pip install pyinstaller eth-account websockets requests
pyinstaller --onefile --windowed --name BTC_Trader btc_trader.py
echo.
echo Done! Output: dist\BTC_Trader.exe
pause
```

- [ ] **Step 2: Commit**

```bash
git add build.bat
git commit -m "feat: build.bat for PyInstaller packaging"
```

---

### Task 6: 最终验证

- [ ] **Step 1: 语法检查**

Run: `python -c "import ast; ast.parse(open('btc_trader.py').read()); print('OK')"`

- [ ] **Step 2: import 检查**

Run: `python -c "import btc_trader; print('imports OK')"`

- [ ] **Step 3: GUI 启动测试**

Run: `python btc_trader.py`
Expected: tkinter 窗口弹出，参数面板可编辑，启动/停止按钮可点击
