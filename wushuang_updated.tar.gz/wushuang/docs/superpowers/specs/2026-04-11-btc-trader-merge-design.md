# BTC 5分钟交易策略 — 合并+GUI设计

## 目标

将 btc_5m_grid.py、btc_5m_unified.py、trade_server.py 合并为单文件 btc_trader.py，带 tkinter GUI，可打包为 Windows exe。

## 文件产出

- `btc_trader.py` — 合并后的单文件
- `build.bat` — PyInstaller 一键打包
- `config.json` — 运行时自动生成

## 类结构

### PolymarketTrader
- 来源：btc_5m_unified.py
- 职责：Polymarket CLOB API 认证（ECDSA签名）、下单、获取持仓
- 方法：sign_message(), get_clob_headers(), place_order(token_id, side, price, size), get_positions()

### PriceWatcher
- 来源：btc_5m_grid.py
- 职责：WebSocket 连接 Polymarket，实时推送 UP/DOWN 价格
- 异步运行，通过回调通知 TradingEngine 价格更新
- 窗口切换时断开重连新 token

### TradingEngine
- 来源：btc_5m_grid.py 的 main() 逻辑
- 职责：交易策略核心
- 状态：up_shares, down_shares, up_hedges[], down_hedges[], last_window
- 策略流程（每个检查周期，5秒间隔）：
  1. 检测5分钟窗口切换 → 重置持仓和对冲队列，重新获取token
  2. 99%止盈 → 市价卖出
  3. 止损（<50%）→ 一次性买入对面方向
  4. 对冲（涨5%）→ 买入对面方向锁定利润
  5. 建仓（55%-85%区间）→ 买入，加入对冲队列（最多2单）
  6. 禁止交易时段检查（北京时间，带30分钟偏移）
- 下单通过 PolymarketTrader 直接调用 API

### TradingApp(tk.Tk)
- 职责：GUI 主窗口
- 左侧：参数配置面板（API Key、钱包地址、私钥、所有交易参数）
- 右侧：实时状态（UP/DOWN价格、剩余时间、持仓、对冲队列）
- 底部：日志滚动输出区域
- 按钮：启动/停止交易
- 配置保存/加载：启动时从 config.json 读取，修改后保存

## 线程模型

- 主线程：tkinter GUI 事件循环
- 交易线程：TradingEngine 运行在 daemon 线程中
- asyncio 事件循环：PriceWatcher 的 WebSocket 在交易线程的 asyncio loop 中运行
- GUI 更新：通过 root.after() 定时从 engine 读取状态刷新界面

## 交易逻辑修正点

从 grid 版移植时需注意：
1. send_order() 替换为 PolymarketTrader.place_order()
2. get_token() 保留原有的正则抓取逻辑
3. is_trading_allowed() 保留北京时间+30分钟偏移逻辑
4. 止盈卖出时 price 参数应为卖出价（0.99），不是 0.01
5. 私钥验证：长度检查应支持带/不带 0x 前缀

## build.bat

```bat
@echo off
pip install pyinstaller eth-account websockets requests
pyinstaller --onefile --windowed --name BTC_Trader btc_trader.py
echo Done! Output: dist\BTC_Trader.exe
pause
```
