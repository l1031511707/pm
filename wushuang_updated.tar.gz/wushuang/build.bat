@echo off
echo === BTC Trader Build ===
pip install pyinstaller py-clob-client websockets requests
pyinstaller --onefile --windowed --name BTC_Trader btc_trader.py
echo.
echo Done! Output: dist\BTC_Trader.exe
pause
